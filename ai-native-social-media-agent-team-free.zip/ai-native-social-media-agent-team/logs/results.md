# Published Results Log (`logs/results.md`)

_Every approved & scheduled item writes here. `results-roi` reads this file to feed `01 SIGNALS` on the next cycle._

| Timestamp | Event / Topic | Department Lead | Channels | SEO Score | Voice Gate | Budget Gate | Outcome |
|---|---|---|---|---|---|---|---|
| 2026-10-22 08:00 | `is retinol worth it (+265%)` | `content-engine` | IG Reel, LinkedIn, YouTube Shorts, Blog | 89/100 | Passed (94%) | ₹0 Organic | Scheduled · +62% positive sentiment |
| 2026-10-22 08:30 | `3-step morning routine` | `content-engine` | IG Carousel, GBP Post, Pinterest | 91/100 | Passed (96%) | ₹0 Organic | Scheduled · 38 profile saves |
| 2026-10-22 08:53 | `specialty coffee hyderabad` | `search-visibility` | IG, LinkedIn, Shorts, GBP | 96/100 | Passed (97%) | ₹0 Organic | Scheduled |
