# Held for Voice Review

_Drafts blocked automatically by the Orchestrator Voice Gate because they violated `owner/brand-voice.md`._

| Timestamp | Department | Violated Rule | Original Blocked Line | Auto-Cleaned Replacement |
|---|---|---|---|---|
| 2026-10-22 08:15 | `content-engine` | ALL CAPS hype + artificial urgency | `"LAST CHANCE!! BUY NOW BEFORE GONE FOREVER!!"` | `"We've got a small batch left this week if it's on your list."` |
