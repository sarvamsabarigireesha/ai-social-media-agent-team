# Needs your OK

_Items wait here when the orchestrator stops. Everything else published itself._
The owner answers with **Hold** or **Approve**.

| ID | Item | Department | Why it stopped | Draft / Action Summary | Status |
|---|---|---|---|---|---|
| OK-101 | Budget check on viral reel | `publishing-social` | Paid boost request requires sign-off per `approval-bar.md` | Boost `reel_042` ("Nobody warns you about week 3") for ₹1,000 over 48h | Pending |
| OK-102 | Competitor 25% flash sale counter | `market-radar` | Replies to a competitor's promo wait for owner | Publish educational value comparison carousel without discounting margin | Pending |
| OK-103 | Late-night DM inquiry (Jasmine) | `leads-conversations` | High-intent consultation booking request at 11:18 PM | Send warm morning slot confirmation link for Friday 5:00 PM | Pending |

## How the owner gets pulled in: a text thread, not a meeting

> **Social media agent:** Post held: Competitor dropped a 25% weekend promo. Drafted a zero-discount "3 steps vs 10 bottles" carousel for 12:30 PM. Approve or Hold?
> **Owner (9:43 AM):** Approve
> **Social media agent:** Approved & scheduled. Margin intact, zero discount given.
