# Brand Voice Guide (`brand-brain/voice-guide.md`)
- Speak like a trusted practitioner talking 1-on-1 over coffee.
- Keep sentences crisp (8–16 words average). Vary rhythm.
- Open with lived customer friction, never generic ("In today's fast-paced world...").
- Replace superlatives ("best ever", "revolutionary") with concrete numbers and timelines.
