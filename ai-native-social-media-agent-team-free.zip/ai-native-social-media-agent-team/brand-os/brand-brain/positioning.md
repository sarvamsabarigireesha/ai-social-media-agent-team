# Positioning Pillar Map (`brand-brain/positioning.md`)
1. **Simplicity Wins**: 3 consistent daily habits beat 12 impulse products.
2. **Honest Timelines**: Real results show up in weeks 3–6, not overnight miracles.
3. **Zero Gatekeeping**: Explain ingredients, pricing, and trade-offs plainly.
