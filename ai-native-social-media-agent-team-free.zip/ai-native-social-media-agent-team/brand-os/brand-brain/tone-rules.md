# Channel Tone Calibration (`brand-brain/tone-rules.md`)
- **Instagram / Reels**: Warm, visual, punchy line breaks, zero jargon.
- **LinkedIn**: Founder/operator lens — customer insight, transparency, clear lesson.
- **GBP / Reviews**: Gracious, specific, local warmth, under 70 words.
- **DMs**: Helpful human concierge — 1 clear answer + 1 easy next question.
