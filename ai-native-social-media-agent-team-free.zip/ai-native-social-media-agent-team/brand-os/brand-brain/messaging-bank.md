# Approved Messaging Bank (`brand-brain/messaging-bank.md`)
- **Tagline**: Fewer steps. Better consistency. Real proof.
- **Value Proof**: "Built for people with 4 minutes in the morning, not 45."
- **Soft CTA Bank**:
  - "Save this for your next restock."
  - "Reply 'ROUTINE' and we'll send the free 3-step checklist."
  - "Two consultation slots open Thursday if you want eyes on yours."
