# Brand Asset Library Index (`creative/asset-library.md`)
- `templates/carousel-cover-dark` — 7-word bold hook + subtle accent pill
- `templates/comparison-split` — "What people buy vs What actually works"
- `templates/reel-lower-third` — Clean captions at safe zone `y: 1380px`
