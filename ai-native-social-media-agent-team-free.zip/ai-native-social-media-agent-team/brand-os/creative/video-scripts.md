# 30-Second Short-Form Video Formula (`creative/video-scripts.md`)
- **0:00–0:03 (Hook)**: Pattern-interrupt visual + spoken 1-line truth.
- **0:03–0:12 (Relatable Friction)**: Name why people get frustrated in week 1–3.
- **0:12–0:24 (Clear Fix)**: Give the 3 concrete steps visually on screen.
- **0:24–0:30 (Warm Close)**: Simple saveable recap + soft CTA.
