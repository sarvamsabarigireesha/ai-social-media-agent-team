# Visual Identity & Layout Specs (`creative/visual-specs.md`)
- **Palette**: Deep Charcoal (`#0B0D0C`), Warm Cream Ink (`#EEF1EC`), Amber Highlight (`#FFB547`), Mint Proof (`#5FE09A`)
- **Typography**: Bold condensed headline max 7 words per slide; generous 80px safe margins
- **Formats**: `1080×1350` Carousel · `1080×1920` Reel/Short · `1200×628` LinkedIn/Blog Card
