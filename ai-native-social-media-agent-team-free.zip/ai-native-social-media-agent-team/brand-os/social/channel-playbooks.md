# Channel Playbooks (`social/channel-playbooks.md`)
- **Instagram**: Carousels drive saves; 30s Reels drive non-follower reach; Stories drive DMs.
- **LinkedIn**: Plain-text hook in first 2 lines before "see more"; real numbers; zero external link penalty in body.
- **YouTube Shorts**: Fast visual cut every 3.5 seconds; loopable ending sentence.
- **Google Business Profile**: Weekly local update with clear photo + neighborhood relevance.
