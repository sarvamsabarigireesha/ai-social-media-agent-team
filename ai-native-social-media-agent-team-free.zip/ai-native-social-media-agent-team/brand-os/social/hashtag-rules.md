# Hashtag & Keyword Tagging Rules (`social/hashtag-rules.md`)
- Maximum **3–5 highly specific niche hashtags** (never 30 spam tags).
- Prioritize natural keywords in the caption and spoken audio for algorithmic search indexing.
