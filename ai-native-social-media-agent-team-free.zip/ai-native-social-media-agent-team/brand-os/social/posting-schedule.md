# Optimal Posting Windows (`social/posting-schedule.md`)
- **Instagram**: 6:30 PM – 8:00 PM local time (Mon / Wed / Fri)
- **LinkedIn**: 9:30 AM – 11:00 AM local time (Tue / Thu)
- **YouTube Shorts**: 7:00 PM local time
- **Google Business Profile**: Thursday 11:30 AM local time
