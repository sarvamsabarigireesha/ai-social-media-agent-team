# Keyword Map (`signals-seo/keyword-map.md`)
| Pillar | Primary Keyword | Monthly Intent | Target Format |
|---|---|---|---|
| Routine Simplicity | `3 step skincare routine` | High Commercial | Pillar Guide + Reel |
| Ingredient Clarity | `is retinol worth it` | High Informational | Myth-vs-Fact Carousel + Blog |
| Sensitive Care | `purging vs breakout how to tell` | Problem-Aware | Comparison Post + FAQ |
| Local Discovery | `best skin consultation near me` | Transactional | GBP Post + Landing Page |
