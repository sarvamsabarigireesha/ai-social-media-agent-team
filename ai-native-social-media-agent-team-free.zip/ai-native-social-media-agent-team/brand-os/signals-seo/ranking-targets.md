# Active Ranking Targets (`signals-seo/ranking-targets.md`)
- Move pages sitting at positions **#8–#15** into Top 5 via fresh examples, internal links, and FAQ blocks.
- Defend Top 3 brand + local service queries weekly.
