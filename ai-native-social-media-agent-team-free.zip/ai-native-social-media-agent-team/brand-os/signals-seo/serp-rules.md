# SERP Winning Rules (`signals-seo/serp-rules.md`)
1. Answer the exact query directly in the **first 45 words** (wins Featured Snippets & AI Overviews).
2. Include at least one clear comparison table or numbered checklist per article.
3. Match real questions from Google Autocomplete in `H2` headings.
