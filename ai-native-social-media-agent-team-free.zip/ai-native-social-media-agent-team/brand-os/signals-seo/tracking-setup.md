# Tracking & UTM Setup (`signals-seo/tracking-setup.md`)
- Format: `?utm_source={channel}&utm_medium=organic_social&utm_campaign={topic_slug}`
- Track profile saves, DM keyword triggers, booking clicks, and assisted organic search lift.
