# Verified FAQ Library (`conversation/faq-library.md`)
- **Q: How long until I see results?**
  A: Most consistent daily routines show clear visible improvement around weeks 3–4.
- **Q: Where do I start if I'm overwhelmed?**
  A: Start with just 3 basics: gentle cleanse, targeted active, and daily broad-spectrum SPF.
- **Q: Can I book a custom consultation / bulk order?**
  A: Yes! Let me check open slots with the owner and share a direct booking link right away.
