# DM & Lead Routing Rules (`conversation/routing-rules.md`)
- **Routine FAQ**: Auto-reply immediately in warm brand voice.
- **High-Intent Buyer / Custom Quote / Complaint**: Send warm acknowledgment immediately + log CRM lead + alert owner in `queue/needs-your-ok.md`.
