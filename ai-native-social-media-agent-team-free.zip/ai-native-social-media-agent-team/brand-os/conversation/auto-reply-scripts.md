# Approved DM Auto-Reply Scripts (`conversation/auto-reply-scripts.md`)
- **Keyword `ROUTINE`**: "Hey! Here's our simple 3-step starter guide — zero fluff. Tell me your main goal right now and I'll point you to the exact section!"
- **After-Hours Inquiry (10 PM – 7 AM)**: "Hey! Thanks so much for reaching out. I've flagged your note for our founder first thing at 8 AM — if you share your preferred day/time, we'll hold a spot for you."
