# Simple Loop Attribution (`reporting/attribution.md`)
- Every DM lead records first-touch content topic (`reel_id` / `post_slug`) in `logs/results.md` so winning topics feed `01 SIGNALS` automatically next week.
