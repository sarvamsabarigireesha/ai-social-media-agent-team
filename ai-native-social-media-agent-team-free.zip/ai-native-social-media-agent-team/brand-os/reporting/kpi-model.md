# North-Star KPI Model (`reporting/kpi-model.md`)
1. **Saves & Shares per 1,000 Views** (measures real usefulness over vanity likes)
2. **Qualified DM Conversations & Bookings**
3. **Organic Non-Branded Search Clicks**
4. **Content Cost per Lead** (Target: ₹0 organic baseline)
