# Margin Protection Rules (`reporting/margin-rules.md`)
- Never counter competitor promos with knee-jerk sitewide discounts below 60% gross margin.
- Lead with bundle clarity, education, and proof before touching price.
