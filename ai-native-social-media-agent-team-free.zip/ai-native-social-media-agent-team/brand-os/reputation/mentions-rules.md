# Brand & Competitor Mentions Rules (`reputation/mentions-rules.md`)
- Answer genuine product comparison questions helpfully.
- Never trash-talk competitors; contrast approaches calmly using `owner/positioning.md`.
