# Review Generation Flow (`reputation/review-flow.md`)
- Trigger polite review invite 48 hours after a completed positive visit/delivery — never gate or incentivize reviews.
