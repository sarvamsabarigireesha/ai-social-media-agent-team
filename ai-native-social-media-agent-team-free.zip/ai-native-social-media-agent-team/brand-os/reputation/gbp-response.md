# Google Review Response Playbook (`reputation/gbp-response.md`)
- **5-Star Review**: Thank by first name, reference the specific detail they loved, warm welcome back (auto-approvable).
- **1–2 Star Review**: Thank them calmly for flagging it, never argue publicly, invite direct resolution offline, **ALWAYS HOLD IN `queue/needs-your-ok.md` FOR OWNER APPROVAL**.
