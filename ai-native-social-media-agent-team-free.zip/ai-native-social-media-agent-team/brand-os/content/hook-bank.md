# Proven Viral Hook Bank (`content/hook-bank.md`)
1. `"Nobody warns you about week 3 of {topic}."`
2. `"You don't need 12 steps for {goal}. You need these 3 done right."`
3. `"The quiet mistake 80% of people make when starting {topic}:"`
4. `"How to tell if {topic} is actually working — or just wasting your budget:"`
5. `"38 customers asked us this exact question about {topic} this month:"`
