# Pre-Publish SEO & Readability Checklist (`content/seo-checklist.md`)
- [x] Target keyword in Title, H1, first 50 words, and at least one H2
- [x] Paragraphs max 3 lines for mobile readability
- [x] Concrete takeaway checklist + 3 real FAQ answers
- [x] Zero filler intros, zero banned hype words (`owner/brand-voice.md`)
