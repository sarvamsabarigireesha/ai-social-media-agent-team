# Standard Content Brief Template (`content/brief-templates.md`)
1. **Trigger Signal**: What search spike, mention, or question sparked this piece?
2. **One Reader Takeaway**: What will they stop worrying about or do differently today?
3. **Hook (First 2 Seconds)**: Scroll-stopping truth without clickbait.
4. **Proof Point**: Specific timeline, mechanism, or real customer pattern.
5. **Soft Next Step**: Save, share, reply keyword, or visit link.
