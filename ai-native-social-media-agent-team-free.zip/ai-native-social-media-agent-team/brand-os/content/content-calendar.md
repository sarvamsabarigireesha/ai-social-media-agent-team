# Weekly Content Calendar (`content/content-calendar.md`)
| Day | Slot | Format | Pillar | Channel Lead |
|---|---|---|---|---|
| Monday | 6:30 PM | 30s Myth-Buster Reel | Ingredient Clarity | Instagram + Shorts |
| Tuesday | 10:30 AM | Founder Insight Post | Behind the Scenes | LinkedIn |
| Wednesday | 6:30 PM | 6-Slide Educational Carousel | Routine Simplicity | Instagram + LinkedIn |
| Thursday | 12:00 PM | Search-Optimized Guide + GBP Update | Local + SEO | Blog + GBP |
| Friday | 6:00 PM | Real Customer Q&A / Proof | Social Proof | Instagram + FB |
