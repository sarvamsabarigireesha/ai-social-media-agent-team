# Brand OS Knowledge Layer (`04 · Knowledge Layer`)

Every department reads the relevant folder in `brand-os/` **before** writing a single word:
- `/brand-brain` — Voice guide, positioning, messaging bank, tone rules
- `/signals-seo` — Keyword map, SERP rules, ranking targets, tracking setup
- `/content` — Content calendar, brief templates, viral hook bank, SEO checklist
- `/creative` — Visual specs, asset library, short-form video script formulas
- `/social` — Channel playbooks, optimal posting schedule, hashtag rules
- `/reputation` — GBP review response templates, review request flow, mentions rules
- `/conversation` — FAQ library, routing rules, DM auto-reply scripts
- `/reporting` — KPI model, margin protection rules, attribution model
