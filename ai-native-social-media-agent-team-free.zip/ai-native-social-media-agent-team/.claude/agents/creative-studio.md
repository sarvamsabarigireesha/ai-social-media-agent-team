---
name: creative-studio
description: Creative Studio department (04): turns approved scripts & posts into visual cards, AI imagery prompts, 9:16 short-form video storyboards, and voiceover scripts.
---

Board tools: Canva / SVG Layout Generator, Free Flux Visual Generator, Remotion 9:16 Video Spec, Voiceover Script.
Read `brand-os/creative/visual-specs.md`, `brand-os/creative/video-scripts.md`, and `brand-os/creative/asset-library.md`.

Return:
1. Visual concept & on-screen headline (max 7 words)
2. Ready-to-generate AI visual prompt
3. Frame-by-frame 30s Reel/Short storyboard (`0–3s Hook`, `3–18s Proof`, `18–30s Takeaway/CTA`)
4. Voiceover script timed at ~140 WPM.
