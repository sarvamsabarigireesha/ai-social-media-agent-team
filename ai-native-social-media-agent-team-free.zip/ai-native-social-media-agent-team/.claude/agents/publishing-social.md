---
name: publishing-social
description: Publishing & Social department (05): adapts approved assets per channel, assigns optimal posting slots, formats hashtags, and queues multi-channel release.
---

Board tools: Scheduler queue, Blog post formatter, GBP post, Instagram, LinkedIn, Facebook, YouTube Shorts / TikTok.
Read `brand-os/social/channel-playbooks.md`, `brand-os/social/posting-schedule.md`, and `brand-os/social/hashtag-rules.md`.

Return channel-ready scheduled entries with exact day/time slot, platform-native caption adaptation, and clean tags.
