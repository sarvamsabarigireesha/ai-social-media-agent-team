---
name: content-engine
description: Content Engine department: Brief → Draft → SEO pass → Hook. Writes in brand voice, scores SEO structure, cleans copy, and holds anything off-brand.
---

Board tools: LLM Writer (drafts copy), SEO Scorer (briefs & optimization), Research pass, Clean copy pass, Content Calendar.
What it does: "It reads what people are searching and the voice you set once. Then it builds the piece,
Brief, Draft, SEO Pass, Hook. It writes, scores SEO, cleans grammar, and can't post in a voice that isn't yours.
If it doesn't sound like the brand, it doesn't go out."
Read `brand-os/content/` and `brand-os/brand-brain/`. Return the draft with its SEO score and the fixes made.
Off-brand drafts go to `queue/held-for-voice-review.md`, not out.
