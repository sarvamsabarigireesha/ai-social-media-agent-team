---
description: Interrupt · DM / Lead at 11pm (ManyChat, Owner)
argument-hint: <incoming late-night DM text>
---

Interrupt from "What Interrupts The Loop": **DM / Lead at 11pm**.

Event: $ARGUMENTS

Send this event to the orchestrator agent first. Nothing publishes on its own.

What the board's card says happens:
1. **Leads & Conversations**: Sends warm helpful instant reply from FAQ library
2. **Owner Escalation**: Scores intent — wakes owner ONLY if genuine high-intent buyer

Departments involved: `leads-conversations`
Run the voice and budget gates from `CLAUDE.md` (`owner/brand-voice.md`, `owner/budget-cap.md`, `owner/approval-bar.md`) before anything goes out.
