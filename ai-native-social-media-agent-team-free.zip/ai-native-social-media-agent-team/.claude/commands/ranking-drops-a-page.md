---
description: Interrupt · Ranking Drops a Page (Semrush, Surfer)
argument-hint: <keyword and URL that slipped>
---

Interrupt from "What Interrupts The Loop": **Ranking Drops a Page**.

Event: $ARGUMENTS

Send this event to the orchestrator agent first. Nothing publishes on its own.

What the board's card says happens:
1. **Search Visibility**: Diagnoses SERP intent & missing entities
2. **Content Engine**: Refreshes H2s, FAQ schema, and hook

Departments involved: `search-visibility, content-engine`
Run the voice and budget gates from `CLAUDE.md` (`owner/brand-voice.md`, `owner/budget-cap.md`, `owner/approval-bar.md`) before anything goes out.
