---
description: Interrupt · Ad Creative Fatigues (Canva, Metricool)
argument-hint: <campaign name and CTR drop>
---

Interrupt from "What Interrupts The Loop": **Ad Creative Fatigues**.

Event: $ARGUMENTS

Send this event to the orchestrator agent first. Nothing publishes on its own.

What the board's card says happens:
1. **Creative Studio**: Rebuilds 3 fresh visual hooks & thumb-stoppers
2. **Publishing & Social**: Rotates creative variants within existing budget cap

Departments involved: `creative-studio, publishing-social`
Run the voice and budget gates from `CLAUDE.md` (`owner/brand-voice.md`, `owner/budget-cap.md`, `owner/approval-bar.md`) before anything goes out.
