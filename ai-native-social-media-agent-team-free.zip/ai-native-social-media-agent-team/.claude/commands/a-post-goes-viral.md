---
description: Interrupt · A Post Goes Viral (Claude, Meta)
argument-hint: <the viral post hook and metrics>
---

Interrupt from "What Interrupts The Loop": **A Post Goes Viral**.

Event: $ARGUMENTS

Send this event to the orchestrator agent first. Nothing publishes on its own.

What the board's card says happens:
1. **Content Engine**: Repurposes winning hook into 3 follow-up formats
2. **Publishing & Results**: Checks budget cap before any paid boost

Departments involved: `publishing-social, results-roi`
Run the voice and budget gates from `CLAUDE.md` (`owner/brand-voice.md`, `owner/budget-cap.md`, `owner/approval-bar.md`) before anything goes out.
