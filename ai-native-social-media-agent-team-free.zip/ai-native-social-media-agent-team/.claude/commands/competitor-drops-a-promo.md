---
description: Interrupt · Competitor Drops a Promo (Brand24, Claude, Canva)
argument-hint: <rival name and promo details>
---

Interrupt from "What Interrupts The Loop": **Competitor Drops a Promo**.

Event: $ARGUMENTS

Send this event to the orchestrator agent first. Nothing publishes on its own.

What the board's card says happens:
1. **Market Radar**: Flags rival promo
2. **Orchestrator + Content Engine**: Re-briefs value angle (holds owner gate per approval-bar.md)
3. **Creative Studio**: Refreshes visual card

Departments involved: `market-radar, content-engine, creative-studio`
Run the voice and budget gates from `CLAUDE.md` (`owner/brand-voice.md`, `owner/budget-cap.md`, `owner/approval-bar.md`) before anything goes out.
