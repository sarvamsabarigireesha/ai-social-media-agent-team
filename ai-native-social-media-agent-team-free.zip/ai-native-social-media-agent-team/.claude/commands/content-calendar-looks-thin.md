---
description: Interrupt · Content Calendar Looks Thin (Claude, Metricool)
argument-hint: <week or gap details>
---

Interrupt from "What Interrupts The Loop": **Content Calendar Looks Thin**.

Event: $ARGUMENTS

Send this event to the orchestrator agent first. Nothing publishes on its own.

What the board's card says happens:
1. **Content Engine**: Fills open calendar slots from Brand OS pillars
2. **Publishing & Social**: Schedules multi-channel queue

Departments involved: `content-engine, publishing-social`
Run the voice and budget gates from `CLAUDE.md` (`owner/brand-voice.md`, `owner/budget-cap.md`, `owner/approval-bar.md`) before anything goes out.
