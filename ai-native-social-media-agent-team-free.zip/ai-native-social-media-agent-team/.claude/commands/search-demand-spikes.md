---
description: Interrupt · Search Demand Spikes (Semrush, Claude)
argument-hint: <a search term or topic and its jump>
---

Interrupt from "What Interrupts The Loop": **Search Demand Spikes**.

Event: $ARGUMENTS

Send this event to the orchestrator agent first. Nothing publishes on its own.

What the board's card says happens:
1. **Semrush / Live Search Signals**: SEO flags spike
2. **Claude / Free AI Engine**: Drafts content

Departments involved: `search-visibility, content-engine`
Run the voice and budget gates from `CLAUDE.md` (`owner/brand-voice.md`, `owner/budget-cap.md`, `owner/approval-bar.md`) before anything goes out.
