---
description: Interrupt · One-Star Review Lands (GBP, Claude, Owner)
argument-hint: <the 1-star review text>
---

Interrupt from "What Interrupts The Loop": **One-Star Review Lands**.

Event: $ARGUMENTS

Send this event to the orchestrator agent first. Nothing publishes on its own.

What the board's card says happens:
1. **Google Business Profile**: Alerts on 1-star review
2. **Reviews & Reputation**: Drafts calm, empathetic reply
3. **Owner Gate**: Holds in queue/needs-your-ok.md for owner OK

Departments involved: `reviews-reputation`
Run the voice and budget gates from `CLAUDE.md` (`owner/brand-voice.md`, `owner/budget-cap.md`, `owner/approval-bar.md`) before anything goes out.
