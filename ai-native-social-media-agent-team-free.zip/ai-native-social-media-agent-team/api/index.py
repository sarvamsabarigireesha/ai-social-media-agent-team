"""
Vercel Serverless Python Entrypoint (`/api/*` routes)
Zero configuration — automatically binds `AgentServerHandler` from `server.py`.
"""
import os
import sys

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from server import AgentServerHandler  # noqa: E402


class handler(AgentServerHandler):
    pass
