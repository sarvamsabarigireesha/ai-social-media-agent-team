# Monthly Budget Cap

_Set once by the owner. Checked by the Orchestrator before any paid boost or spend._
OWNER INPUT · human-led · not counted as an agent.

## Monthly Limits
- **Organic Social, SEO & AI Content Pipeline**: ₹0 / $0 (100% Free Self-Hosted Stack)
- **Monthly Paid Boost Cap**: ₹10,000 ($120) total across all channels
- **Single Post Boost Threshold**: ₹1,500 ($18) max without explicit owner approval
- **Current Month Spend Used**: ₹4,200 (42% of cap)

## Hard Rules
1. At **85%+ of monthly cap**, hold ALL paid boosts and alert the owner in `queue/needs-your-ok.md`.
2. Routine organic posts cost ₹0 and ship automatically once they pass `owner/brand-voice.md`.
3. Never raise daily or monthly ad caps automatically.
