# Approval bar

_What ships without the owner and what waits for a yes._
OWNER INPUT · human-led · not counted as an agent.

## Ships on its own
- Routine organic educational, storytelling, SEO, and community content that passes the voice check (`owner/brand-voice.md`) and stays inside the budget (`owner/budget-cap.md`).
- Standard 4–5 star review thank-you notes and FAQ-backed DM answers that make zero custom promises.

## Waits for the owner (goes to `queue/needs-your-ok.md`)
- Budget changes or any paid boost request above threshold
- 1-star or 2-star reviews and any customer complaint
- Edge cases or sensitive public mentions
- Anything that reads like a promise (custom prices, discounts, guarantees, results, availability)
- A reply to a competitor's promo
- High-intent late-night leads asking for custom quotes or urgent bookings
