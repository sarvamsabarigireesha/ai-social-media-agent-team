# Brand Voice

_Set once, checked on every draft._
OWNER INPUT · human-led · not counted as an agent.

## Voice in one paragraph
> Warm, confident, a little playful. Talks like a knowledgeable friend, never a lecture.
> Short sentences. No hard-sell language. Every claim has to be something we can actually back up.

## Do
- Friendly, clear everyday words
- Specific, verifiable claims
- Real customer stories & practical takeaways
- Emoji, sparingly (max 1–2 when natural)

## Never
- ALL CAPS hype ("LIMITED SPOTS!!", "ACT NOW!!", "INSANE DEAL!!")
- Fear-based hooks or shaming language
- Unverified medical, financial, or guaranteed outcome claims

## Dials (0–100)
| Warmth | Confidence | Playfulness | Formality |
|---|---|---|---|
| 92 | 84 | 61 | 28 |

## Examples
- ✗ "LIMITED SPOTS!! Book NOW before it's too late!!" (rejected: hype + urgency)
- ✓ "We've got two openings left this week if you've been meaning to come in." (approved)

## Sample caption on file
> Your routine doesn't need 12 complicated steps. It needs the right 3, done consistently. Here's what we actually recommend starting with.
