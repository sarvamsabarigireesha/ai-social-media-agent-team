# Brand Positioning

_Set once by the owner. Every department reads this before briefing or drafting._
OWNER INPUT · human-led · not counted as an agent.

## Who We Serve
- **Brand Name**: GlowCraft Studio (Customize for your business in 1 click on the Dashboard!)
- **Category**: Evidence-based skincare & daily ritual studio
- **Audience**: Busy professionals & founders (ages 22–42) tired of overhyped 12-step routines and confusing ingredient jargon.

## Core Promise (Without Hype)
Simple, science-backed 3-step routines explained like an honest friend — zero fear marketing, zero miracle claims.

## Why Customers Pick Us Over Rivals
1. **Clarity over clutter**: 3 effective essentials instead of 10 overlapping bottles.
2. **Proof over hype**: Real timelines (3–4 weeks consistency), honest purging guidance, transparent pricing.
3. **Human warmth**: Zero pushy sales scripts.
